import requests
import json
import uuid

url = 'https://fj34qg22id.execute-api.us-east-1.amazonaws.com/sandbox/writeid'
auth_token = str(uuid.uuid4())
headers = {'Authorization': auth_token, 'Content-Type': 'application/json'}
data = {"TableName":"iosUser", "Item":{"apple_id":{"S":"234567"}}}
response = requests.post(url, headers=headers, data=json.dumps(data))

print(response.status_code)
print(response.text)
