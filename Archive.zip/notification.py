import requests
import json
import http.client as http_client
import requests

http_client.HTTPConnection.debuglevel = 1


# Set up the request headers and body
device_token = 'cd4e0575907e4e219b89800d1e86d9b1fe9ab126f5ab20c1d41ad1fdb71cbf9c'
apns_topic = 'com.munozcreates.ambulane'
headers = {
    'apns-topic': apns_topic,
    'apns-push-type': 'alert'
}
payload = {
    'aps': {
        'alert': {
            'title': 'My Notification Title',
            'body': 'My Notification Body'
        },
        'sound': 'default'
    }
}

# Convert the payload to JSON
payload_json = json.dumps(payload)

# Send the request to the APNs server
response = requests.post(f'https://api.development.push.apple.com/3/device/{device_token}',
                         headers=headers,
                         data=payload_json,
                         cert=('AmbulaneCert.pem', 'key.pem'))

# Check the response status code
if response.status_code == 200:
    print('Notification sent successfully.')
else:
    print(f'Failed to send notification. Error code: {response.status_code}')

